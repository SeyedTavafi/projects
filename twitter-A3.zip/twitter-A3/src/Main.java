// Seyed Tavafi
// CS3560
// miniTweeter
/*In this programming assignment, you will build a Java-based Mini Twitter with graphical user
interface (GUI) using Java Swing . This is going to be a pure desktop program, without web or
mobile components. The goal of this assignment is to let you experience how to apply design
patterns to build extensible software systems.*/

import view.*;
import Pool.*;

public class Main {
    private static ControlPanel CP;

    public static void main(String[] args) {
        Main.getControlPanelInstance();
    }

    /**
     * This method is used to get instance of Control Panel
     *
     * @return ControlPanel This returns ControlPanel.
     */
    public static ControlPanel getControlPanelInstance() {
        if (CP == null) {
            new ControlPanel(new Pool());
        }
        return CP;
    }
}
  
// Seyed Tavafi
// CS3560
// miniTweeter project 3
package Visitors;

import Pool.Pool;
import Message.Message;

public class CalculatePercentageVisitor implements CalculatePercentageVisitorable {
    /*
     * this method to visit
     * return find word count
     */
    public double visit(Pool pool, String word) {
        double findWordCount = 0;
        if (pool.getMessages().toArray().length != 0) {
            for (int i = 0; i < pool.getMessages().toArray().length; i++) {
                Message msg = (Message) pool.getMessages().toArray()[i];
                findWordCount = findWordCount + countOccurences(msg.getMessage(), word);
            }
            return Math.round((findWordCount / pool.getMessages().toArray().length) * 100);
        }
        return findWordCount;
    }

    /*
     * this method to count occurences
     * return count
     */
    private int countOccurences(String str, String word) {
        String messageArray[] = str.split(" ");
        int count = 0;
        for (int i = 0; i < messageArray.length; i++) {
            if (word.equals(messageArray[i]))
                count++;
        }
        return count;
    }
}

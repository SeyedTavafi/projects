  
// Seyed Tavafi
// CS3560
// miniTweeter project 3
package User;

import java.util.Date;
import java.util.Arrays;
import java.util.Calendar;
import java.text.SimpleDateFormat;

import Group.Group;
import Message.Message;
import Observers.LastActivityObserver;

public class User {
    private String id;
    private Group group = null;
    private Message[] recivedMessages = {};
    private Message[] sentMessages = {};
    private User[] followers = {};
    private User[] followings = {};
    private String createDateTime;
    private String lastActivity = "Without Activity";
    private Date lastActivityObject = new Date();

    public User(String id) {
        setCreateDateTime();
        setId(id);
    }

    /**
     * This method is used to set id
     *
     * @param id This is the first paramter
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * This method is used to set group
     *
     * @param group This is the first paramter
     */
    public void setGroup(Group group) {
        this.group = group;
    }

    /**
     * This method is used to set follower to follower array
     *
     * @param follower This is the first paramter
     */
    public void setFollowers(User follower) {
        int n = this.followers.length;
        User[] array = new User[n + 1];
        for (int i = 0; i < n; i++)
            array[i] = followers[i];
        array[n] = follower;
        this.followers = array;
    }

    /**
     * This method is used to set following to following array
     *
     * @param following This is the first paramter
     */
    public void setFollowing(User following) {
        int n = this.followings.length;
        User[] array = new User[n + 1];
        for (int i = 0; i < n; i++)
            array[i] = followings[i];
        array[n] = following;
        this.followings = array;
    }

    /**
     * This method is used to set sent message to sent message array
     *
     * @param sentMessage This is the first paramter
     */
    public void setSentMessages(Message sentMessage) {
        int n = this.sentMessages.length;
        Message[] array = new Message[n + 1];
        for (int i = 0; i < n; i++)
            array[i] = sentMessages[i];
        array[n] = sentMessage;
        this.sentMessages = array;
    }

    /**
     * This method is used to set recived message to recived message array
     *
     * @param recivedMessage This is the first paramter
     */
    public void setRecivedMessages(Message recivedMessage) {
        int n = this.recivedMessages.length;
        Message[] array = new Message[n + 1];
        for (int i = 0; i < n; i++)
            array[i] = recivedMessages[i];
        array[n] = recivedMessage;
        this.recivedMessages = array;
    }

    /**
     * This method is used to get id
     *
     * @return id This returns id.
     */
    public String getId() {
        return id;
    }

    /**
     * This method is used to get group
     *
     * @return group This returns group.
     */
    public Group getGroup() {
        return group;
    }

    /**
     * This method is used to get followers
     *
     * @return User[] This returns followers.
     */
    public User[] getFollowers() {
        return followers;
    }

    /**
     * This method is used to get followings
     *
     * @return User[] This returns followings.
     */
    public User[] getFollowings() {
        return followings;
    }

    /**
     * This method is used to get sentMessages
     *
     * @return Message[] This returns sentMessages.
     */
    public Message[] getSentMessages() {
        return sentMessages;
    }

    /**
     * This method is used to get recivedMessages
     *
     * @return Message[] This returns recivedMessages.
     */
    public Message[] getRecivedMessages() {
        return recivedMessages;
    }

    /**
     * This method is used to get create date
     *
     * @return String This returns create date.
     */
    public String getCreateDate() {
        return createDateTime;
    }

    /**
     * This method is used to set create date
     */
    public void setCreateDateTime() {
        this.createDateTime = new SimpleDateFormat("yyyy/MM/dd_HH:mm:ss").format(Calendar.getInstance().getTime());
    }

    public String toString() {
        return "id : " + id + "sent messages=" + Arrays.toString(sentMessages) + "recived messages="
                + Arrays.toString(recivedMessages);
    }

    /**
     * This method is used to set last activity
     */
    public void setLastActivity() {
        lastActivity = null;
        LastActivityObserver obj = (new LastActivityObserver()).update();
        this.lastActivity = obj.getStringDate();
        this.lastActivityObject = obj.getDate();
    }

    /**
     * This method is used to get last activity
     *
     * @return String This returns last activity.
     */
    public String getLastActivity() {
        return lastActivity;
    }

    /**
     * This method is used to get last activity
     *
     * @return Date This returns last activity.
     */
    public Date getLastActivityObject() {
        return lastActivityObject;
    }
}

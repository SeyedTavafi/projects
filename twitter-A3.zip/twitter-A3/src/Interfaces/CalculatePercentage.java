// Seyed Tavafi
// CS3560
// miniTweeter project 3
package Interfaces;

import Visitors.CalculatePercentageVisitor;

public interface CalculatePercentage {
    /*
     *
     * @param CalculatePercentageVisitor visitor
     * @param String word
     *
     * */
    public double accept(CalculatePercentageVisitor visitor, String word);
}

package voting;

public interface VotingSystemInterface {
    /**
     * voting system.
     */
    void voting();

    /**
     * The result of answering questions.
     */
    void result();
}

package voting;

import question.*;
import student.Student;

import java.util.Random;

public class VotingSystem implements VotingSystemInterface{

    private final Student[] students;
    private final Question[] questions;

    public VotingSystem(Student[] students, Question[] questions) {
        this.students = students;
        this.questions = questions;
    }

    /**
     * voting system.
     */
    public void voting() {

        for (int i = 0; i < students.length; i++) {

            String studentName = students[i].getFullName();

            System.out.println("\n" + "NAME : " + studentName + "=>");

            for (int j = 0; j < questions.length; j++) {

                Question question = questions[j].clone("" + questions[j].getQuestion());

                if (question.getType().equals("both") && Math.random() > 0.5) {

                    BothAnswerType answer = BothAnswerType.values()[new Random().nextInt(BothAnswerType.values().length)];
                    question.setAnswer(answer);

                    BothQuestion q = (BothQuestion) questions[j];
                    if ("Right".equals("" + answer)) {
                        q.addRightOption();
                    } else if ("Wrong".equals("" + answer)) {
                        q.addWrongOption();
                    }


                } else if (question.getType().equals("multi") && Math.random() > 0.5) {
                    MultiAnswerType answer = MultiAnswerType.values()[new Random().nextInt(MultiAnswerType.values().length)];
                    question.setAnswer(answer);

                    MultiQuestion q = (MultiQuestion) questions[j];
                    if ("A".equals("" + answer)) {
                        q.add_A();
                    } else if ("B".equals("" + answer)) {
                        q.add_B();
                    } else if ("C".equals("" + answer)) {
                        q.add_C();
                    } else if ("D".equals("" + answer)) {
                        q.add_D();
                    }
                }

                System.out.println("    question(" + question.getType() + ") => " + question.getQuestion());
                System.out.println("        answer => " + question.getAnswer() + "\n");
            }
        }
    }

    /**
     * The result of answering questions.
     */
    public void result() {
        for (int i = 0; i < questions.length; i++) {
            if (questions[i].getType().equals("both")) {
                BothQuestion q = (BothQuestion) questions[i];
                System.out.println(q.getQuestion());
                System.out.println("    Right : " + q.getRightOption());
                System.out.println("    Wrong : " + q.getWrongOption());
            } else if (questions[i].getType().equals("multi")) {
                MultiQuestion q = (MultiQuestion) questions[i];
                System.out.println(q.getQuestion());
                System.out.println("    A : " + q.get_A());
                System.out.println("    B : " + q.get_B());
                System.out.println("    C : " + q.get_C());
                System.out.println("    D : " + q.get_D());
            }
        }
    }
}
